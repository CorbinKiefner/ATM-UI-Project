﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace CorbinKiefnerATM
{
    public partial class Deposit : Form
    {
        //database link
        MySqlConnection link = new MySqlConnection("server=157.89.28.29;user=student;database=csc340_db;port=3306;password=Maroon@21?;");
        
        //Deposit number information
        private string depositAmt = "";
        private int amtLength = 0;
        
        //Database update variables
        int oldBalance;
        int depositAmountDB;
        int updatedBalance;
        string updatedBalanceDB;

        //store balances for each account and get checking account numbers
        private string bal1 = "";
        private string bal2 = "";
        private string bal3 = "";
        private string bal4 = "";
        private string checking1 = "";
        private string checking2 = "";
        private string checking3 = "";
        private string checking4 = "";

        //current balance and current limit progress
        private string currentBalance = "";
        private int currentLimit;
        private int boxIndex;

        //initialization
        public Deposit()
        {
            InitializeComponent();
            
            //disable specific buttons
            button0.Enabled = false;
            buttonDelete.Enabled = false;
            buttonEnter.Enabled = false;
            
            //Open database
            link.Open();

            //Get current limit progress
            MySqlCommand getCurrentLimit = new MySqlCommand("SELECT currentLimit FROM corbinkiefneratmtransaction", link);
            currentLimit = int.Parse(getCurrentLimit.ExecuteScalar().ToString());

            //Gather balances
            MySqlCommand DB1 = new MySqlCommand("SELECT balance1 FROM corbinkiefneratmbalances", link);
            bal1 = DB1.ExecuteScalar().ToString();
            MySqlCommand DB2 = new MySqlCommand("SELECT balance2 FROM corbinkiefneratmbalances", link);
            bal2 = DB2.ExecuteScalar().ToString();
            MySqlCommand DB3 = new MySqlCommand("SELECT balance3 FROM corbinkiefneratmbalances", link);
            bal3 = DB3.ExecuteScalar().ToString();
            MySqlCommand DB4 = new MySqlCommand("SELECT balance4 FROM corbinkiefneratmbalances", link);
            bal4 = DB4.ExecuteScalar().ToString();

            //Gather account numbers
            MySqlCommand getchecking1 = new MySqlCommand("SELECT account1 FROM corbinkiefneratmbalances", link);
            checking1 = (getchecking1.ExecuteScalar().ToString());
            MySqlCommand getchecking2 = new MySqlCommand("SELECT account2 FROM corbinkiefneratmbalances", link);
            checking2 = (getchecking2.ExecuteScalar().ToString());
            MySqlCommand getchecking3 = new MySqlCommand("SELECT account3 FROM corbinkiefneratmbalances", link);
            checking3 = (getchecking3.ExecuteScalar().ToString());
            MySqlCommand getchecking4 = new MySqlCommand("SELECT account4 FROM corbinkiefneratmbalances", link);
            checking4 = (getchecking4.ExecuteScalar().ToString());

            //Close database
            link.Close();
            
            //set default textbox content
            accountBalanceTB.Text = "$" + currentBalance + ".00";
            depositAmountTB.Text = "$0.00";
            
            //initialize combobox items and select default
            depositAccountCB.Items.Add(checking1);
            depositAccountCB.Items.Add(checking2);
            depositAccountCB.Items.Add(checking3);
            depositAccountCB.Items.Add(checking4);
            depositAccountCB.SelectedIndex = 0;
        }

        //return to main menu
        private void mainMenuButton_Click(object sender, EventArgs e)
        {
            this.Hide();
            Home form = new Home();
            form.ShowDialog();
            this.Close();
        }

        //log out
        private void logOutButton_Click(object sender, EventArgs e)
        {
            this.Hide();
            LogIn form = new LogIn();
            form.ShowDialog();
            this.Close();
        }

        //combobox controls
        private void depositAccountCB_SelectedIndexChanged(object sender, EventArgs e)
        {
            //Set up the index variable for later use
            boxIndex = depositAccountCB.SelectedIndex + 1;

            //Switch indicates which item the user has selected using the index above
            switch (boxIndex)
            {
                case 1:
                    currentBalance = bal1;
                    accountBalanceTB.Text = "$" + currentBalance + ".00";
                    break;
                case 2:
                    currentBalance = bal2;
                    accountBalanceTB.Text = "$" + currentBalance + ".00";
                    break;
                case 3:
                    currentBalance = bal3;
                    accountBalanceTB.Text = "$" + currentBalance + ".00";
                    break;
                case 4:
                    currentBalance = bal4;
                    accountBalanceTB.Text = "$" + currentBalance + ".00";
                    break;
            }
        }

        //enter button
        private void buttonEnter_Click(object sender, EventArgs e)
        {
            //disable certain buttons
            button0.Enabled = false;
            buttonDelete.Enabled = false;
            buttonEnter.Enabled = false;

            //Old balance and deposit amount
            oldBalance = int.Parse(currentBalance);
            depositAmountDB = int.Parse(depositAmt);

            //New balance
            updatedBalance = oldBalance + depositAmountDB;
            updatedBalanceDB = updatedBalance.ToString();

            //if the deposit is a valid transaction...
            if (currentLimit <=  (3000 - depositAmountDB))
            {
                //change current limit after valid transaction
                currentLimit += depositAmountDB;
                
                //deposit confirmation message
                errorLabel.Text = "$" + depositAmt + ".00 deposited.";
                
                //set the textbox back to normal
                depositAmt = "";
                amtLength = 0;
                depositAmountTB.Text = "$0.00";

                //Update the database
                link.Open();
                MySqlCommand updateDatabaseBalance = new MySqlCommand("UPDATE corbinkiefneratmbalances SET balance" + boxIndex + " = " + updatedBalanceDB, link);
                updateDatabaseBalance.ExecuteNonQuery();
                MySqlCommand updateDatabaseLimit = new MySqlCommand("UPDATE corbinkiefneratmtransaction SET currentLimit = " + currentLimit, link);
                updateDatabaseLimit.ExecuteNonQuery();
                MySqlCommand lastTransaction = new MySqlCommand("UPDATE corbinkiefneratmtransaction SET lastTransactionAmount = " + depositAmountDB, link);
                lastTransaction.ExecuteNonQuery();
                MySqlCommand selectBalanceCB = new MySqlCommand("SELECT balance" + boxIndex + " FROM corbinkiefneratmbalances", link);
                currentBalance = selectBalanceCB.ExecuteScalar().ToString();
                link.Close();
            }
            //if the deposit is NOT a valid transaction...
            else
            {
                //let the user know why the deposit failed
                errorLabel.Text = "This exceeds your daily limit.";

                //set textbox back to normal
                depositAmt = "";
                amtLength = 0;
                depositAmountTB.Text = "$0.00";
            }

            //disable certain buttons again
            button0.Enabled = false;
            buttonDelete.Enabled = false;
            buttonEnter.Enabled = false;

            //call the correct balance according to the indicated combobox index
            switch (boxIndex)
            {
                case 1:
                    bal1 = currentBalance;
                    break;
                case 2:
                    bal2 = currentBalance;
                    break;
                case 3:
                    bal3 = currentBalance;
                    break;
                case 4:
                    bal4 = currentBalance;
                    break;
            }

            //set textbox to normal
            accountBalanceTB.Text = "$" + currentBalance + ".00";
        }

        //button "1"
        private void button1_Click(object sender, EventArgs e)
        {
            if (amtLength < 10)
            {
                depositAmt = depositAmt + 1;
                amtLength++;
                button0.Enabled = true;
                buttonDelete.Enabled = true;
                buttonEnter.Enabled = true;
            }

            depositAmountTB.Text = "$" + depositAmt + ".00";
        }

        //button "2"
        private void button2_Click(object sender, EventArgs e)
        {
            if (amtLength < 10)
            {
                depositAmt = depositAmt + 2;
                amtLength++;
                button0.Enabled = true;
                buttonDelete.Enabled = true;
                buttonEnter.Enabled = true;
            }

            depositAmountTB.Text = "$" + depositAmt + ".00";
        }

        //button "3"
        private void button3_Click(object sender, EventArgs e)
        {
            if (amtLength < 10)
            {
                depositAmt = depositAmt + 3;
                amtLength++;
                button0.Enabled = true;
                buttonDelete.Enabled = true;
                buttonEnter.Enabled = true;
            }

            depositAmountTB.Text = "$" + depositAmt + ".00";
        }

        //button "4"
        private void button4_Click(object sender, EventArgs e)
        {
            if (amtLength < 10)
            {
                depositAmt = depositAmt + 4;
                amtLength++;
                button0.Enabled = true;
                buttonDelete.Enabled = true;
                buttonEnter.Enabled = true;
            }

            depositAmountTB.Text = "$" + depositAmt + ".00";
        }

        //button "5"
        private void button5_Click(object sender, EventArgs e)
        {
            if (amtLength < 10)
            {
                depositAmt = depositAmt + 5;
                amtLength++;
                button0.Enabled = true;
                buttonDelete.Enabled = true;
                buttonEnter.Enabled = true;
            }

            depositAmountTB.Text = "$" + depositAmt + ".00";
        }

        //button "6"
        private void button6_Click(object sender, EventArgs e)
        {
            if (amtLength < 10)
            {
                depositAmt = depositAmt + 6;
                amtLength++;
                button0.Enabled = true;
                buttonDelete.Enabled = true;
                buttonEnter.Enabled = true;
            }

            depositAmountTB.Text = "$" + depositAmt + ".00";
        }

        //button "7"
        private void button7_Click(object sender, EventArgs e)
        {
            if (amtLength < 10)
            {
                depositAmt = depositAmt + 7;
                amtLength++;
                button0.Enabled = true;
                buttonDelete.Enabled = true;
                buttonEnter.Enabled = true;
            }

            depositAmountTB.Text = "$" + depositAmt + ".00";
        }

        //button "8"
        private void button8_Click(object sender, EventArgs e)
        {
            if (amtLength < 10)
            {
                depositAmt = depositAmt + 8;
                amtLength++;
                button0.Enabled = true;
                buttonDelete.Enabled = true;
                buttonEnter.Enabled = true;
            }

            depositAmountTB.Text = "$" + depositAmt + ".00";
        }

        //button "9"
        private void button9_Click(object sender, EventArgs e)
        {
            if (amtLength < 10)
            {
                depositAmt = depositAmt + 9;
                amtLength++;
                button0.Enabled = true;
                buttonDelete.Enabled = true;
                buttonEnter.Enabled = true;
            }

            depositAmountTB.Text = "$" + depositAmt + ".00";
        }

        //button "0"
        private void button0_Click(object sender, EventArgs e)
        {
            if (amtLength < 10)
            {
                depositAmt = depositAmt + 0;
                amtLength++;
                buttonDelete.Enabled = true;
                buttonEnter.Enabled = true;
            }

            depositAmountTB.Text = "$" + depositAmt + ".00";
        }

        //delete button
        private void buttonDelete_Click(object sender, EventArgs e)
        {
            //if the textbox has digits in it
            if (amtLength > 0)
            {
                //delete the digits
                depositAmt = depositAmt.Substring(0, depositAmt.Length - 1);
                depositAmountTB.Text = "$" + depositAmt + ".00";
                amtLength--;
            }
            //if the textbox does NOT have digits in it
            if (amtLength == 0)
            {
                //disable buttons and set the textbox to default
                button0.Enabled = false;
                buttonDelete.Enabled = false;
                buttonEnter.Enabled = false;
                depositAmountTB.Text = "$0.00";
            }
        }
    }
}
