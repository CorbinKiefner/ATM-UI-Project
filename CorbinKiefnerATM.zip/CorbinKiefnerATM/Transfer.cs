﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace CorbinKiefnerATM
{
    public partial class Transfer : Form
    {
        //set up necessary variables for transfer method
        bool canEnter = false;
        private int amtLength = 0;
        private string transferAmt = "";
        private string balanceSwapOne = "";
        private string balanceSwapTwo = "";
        int oldBalanceOne;
        int oldBalanceTwo;
        int transferAmtDB;
        int updatedBalanceOne = 0;
        int updatedBalanceTwo = 0;
        string updatedBalanceOneDB = "";
        string updatedBalanceTwoDB = "";

        //store balances for each account and get checking account numbers
        private string bal1 = "";
        private string bal2 = "";
        private string bal3 = "";
        private string bal4 = "";
        private string checking1;
        private string checking2;
        private string checking3;
        private string checking4;

        //combobox index control
        private int boxIndexOne;
        private int boxIndexTwo;

        //database link
        MySqlConnection link = new MySqlConnection("server=157.89.28.29;user=student;database=csc340_db;port=3306;password=Maroon@21?;");

        //initialization
        public Transfer()
        {
            InitializeComponent();
            
            //disable certain buttons and set default textbox
            button0.Enabled = false;
            buttonDelete.Enabled = false;
            buttonEnter.Enabled = false;
            transferAmountTB.Text = "$0.00";

            //open database
            link.Open();

            //gather balances from DB
            MySqlCommand DB1 = new MySqlCommand("SELECT balance1 FROM corbinkiefneratmbalances", link);
            bal1 = DB1.ExecuteScalar().ToString();
            MySqlCommand DB2 = new MySqlCommand("SELECT balance2 FROM corbinkiefneratmbalances", link);
            bal2 = DB2.ExecuteScalar().ToString();
            MySqlCommand DB3 = new MySqlCommand("SELECT balance3 FROM corbinkiefneratmbalances", link);
            bal3 = DB3.ExecuteScalar().ToString();
            MySqlCommand DB4 = new MySqlCommand("SELECT balance4 FROM corbinkiefneratmbalances", link);
            bal4 = DB4.ExecuteScalar().ToString();

            //gather account numbers from DB
            MySqlCommand getchecking1 = new MySqlCommand("SELECT account1 FROM corbinkiefneratmbalances", link);
            checking1 = (getchecking1.ExecuteScalar().ToString());
            MySqlCommand getchecking2 = new MySqlCommand("SELECT account2 FROM corbinkiefneratmbalances", link);
            checking2 = (getchecking2.ExecuteScalar().ToString());
            MySqlCommand getchecking3 = new MySqlCommand("SELECT account3 FROM corbinkiefneratmbalances", link);
            checking3 = (getchecking3.ExecuteScalar().ToString());
            MySqlCommand getchecking4 = new MySqlCommand("SELECT account4 FROM corbinkiefneratmbalances", link);
            checking4 = (getchecking4.ExecuteScalar().ToString());

            //close database
            link.Close();

            //initialize first combobox and set up default selection
            withdrawalAccountCB.Items.Add(checking1);
            withdrawalAccountCB.Items.Add(checking2);
            withdrawalAccountCB.Items.Add(checking3);
            withdrawalAccountCB.Items.Add(checking4);
            withdrawalAccountCB.SelectedIndex = 0;

            //initialize second combobox and set up default selection
            depositAccountCB.Items.Add(checking1);
            depositAccountCB.Items.Add(checking2);
            depositAccountCB.Items.Add(checking3);
            depositAccountCB.Items.Add(checking4);
            depositAccountCB.SelectedIndex = 1;
        }

    //return to main menu
    private void mainMenuButton_Click(object sender, EventArgs e)
        {
            this.Hide();
            Home form = new Home();
            form.ShowDialog();
            this.Close();
        }

        //log out
        private void logOutButton_Click(object sender, EventArgs e)
        {
            this.Hide();
            LogIn form = new LogIn();
            form.ShowDialog();
            this.Close();
        }

        //select withdraw account combobox
        private void withdrawalAccountCB_SelectedIndexChanged(object sender, EventArgs e)
        {
            //Set up the index variable for later use with the combo box
            boxIndexOne = withdrawalAccountCB.SelectedIndex + 1;

            //Switch indicates which item the user has selected, and changes the balance textbox accordingly
            switch (boxIndexOne)
            {
                case 1:
                    withdrawalBalanceTB.Text = "$" + bal1 + ".00";
                    balanceSwapOne = bal1;
                    break;
                case 2:
                    withdrawalBalanceTB.Text = "$" + bal2 + ".00";
                    balanceSwapOne = bal2;
                    break;
                case 3:
                    withdrawalBalanceTB.Text = "$" + bal3 + ".00";
                    balanceSwapOne = bal3;
                    break;
                case 4:
                    withdrawalBalanceTB.Text = "$" + bal4 + ".00";
                    balanceSwapOne = bal4;
                    break;
            }

            //If the comboboxes are not the same account
            if (boxIndexOne != boxIndexTwo)
            {
                errorLabel.Text = "";
                canEnter = true;
            }
            //If the comboboxes are the same account
            else
            {
                errorLabel.Text = "Select different accounts before continuing.";
                canEnter = false;
            }

            //if the user can enter, enable buttons. If they cannot, disable them.
            switch (canEnter)
            {
                case true:
                    button1.Enabled = true;
                    button2.Enabled = true;
                    button3.Enabled = true;
                    button4.Enabled = true;
                    button5.Enabled = true;
                    button6.Enabled = true;
                    button7.Enabled = true;
                    button8.Enabled = true;
                    button9.Enabled = true;
                    if (amtLength != 0)
                    {
                        button0.Enabled = true;
                        buttonDelete.Enabled = true;
                        buttonEnter.Enabled = true;
                    }
                    break;
                case false:
                    button1.Enabled = false;
                    button2.Enabled = false;
                    button3.Enabled = false;
                    button4.Enabled = false;
                    button5.Enabled = false;
                    button6.Enabled = false;
                    button7.Enabled = false;
                    button8.Enabled = false;
                    button9.Enabled = false;
                    button0.Enabled = false;
                    buttonDelete.Enabled = false;
                    buttonEnter.Enabled = false;
                    break;
            }
        }

        //select deposit account combobox
        private void depositAccountCB_SelectedIndexChanged(object sender, EventArgs e)
        {
            //Set up the index variable for later use with the combo box
            boxIndexTwo = depositAccountCB.SelectedIndex + 1;

            //Switch indicates which item the user has selected, and changes the balance textbox accordingly
            switch (boxIndexTwo)
            {
                case 1:
                    depositBalanceTB.Text = "$" + bal1 + ".00";
                    balanceSwapTwo = bal1;
                    break;
                case 2:
                    depositBalanceTB.Text = "$" + bal2 + ".00";
                    balanceSwapTwo = bal2;
                    break;
                case 3:
                    depositBalanceTB.Text = "$" + bal3 + ".00";
                    balanceSwapTwo = bal3;
                    break;
                case 4:
                    depositBalanceTB.Text = "$" + bal4 + ".00";
                    balanceSwapTwo = bal4;
                    break;
            }

            //If the comboboxes are not the same account
            if (boxIndexOne != boxIndexTwo)
            {
                errorLabel.Text = "";
                canEnter = true;
            }
            //If the comboboxes are the same account
            else
            {
                errorLabel.Text = "Select different accounts before continuing.";
                canEnter = false;
            }

            //if the user can enter, enable buttons. If they cannot, disable them.
            switch (canEnter)
            {
                case true:
                    button1.Enabled = true;
                    button2.Enabled = true;
                    button3.Enabled = true;
                    button4.Enabled = true;
                    button5.Enabled = true;
                    button6.Enabled = true;
                    button7.Enabled = true;
                    button8.Enabled = true;
                    button9.Enabled = true;
                    if (amtLength != 0)
                    {
                        button0.Enabled = true;
                        buttonDelete.Enabled = true;
                        buttonEnter.Enabled = true;
                    }
                    break;
                case false:
                    button1.Enabled = false;
                    button2.Enabled = false;
                    button3.Enabled = false;
                    button4.Enabled = false;
                    button5.Enabled = false;
                    button6.Enabled = false;
                    button7.Enabled = false;
                    button8.Enabled = false;
                    button9.Enabled = false;
                    button0.Enabled = false;
                    buttonDelete.Enabled = false;
                    buttonEnter.Enabled = false;
                    break;
            }
        }

        //button "1"
        private void button1_Click(object sender, EventArgs e)
        {
            if (amtLength < 10 && canEnter)
            {
                transferAmt = transferAmt + 1;
                amtLength++;
                button0.Enabled = true;
                buttonDelete.Enabled = true;
                buttonEnter.Enabled = true;
            }

            transferAmountTB.Text = "$" + transferAmt + ".00";
        }

        //button "2"
        private void button2_Click(object sender, EventArgs e)
        {
            if (amtLength < 10 && canEnter)
            {
                transferAmt = transferAmt + 2;
                amtLength++;
                button0.Enabled = true;
                buttonDelete.Enabled = true;
                buttonEnter.Enabled = true;
            }

            transferAmountTB.Text = "$" + transferAmt + ".00";
        }

        //button "3"
        private void button3_Click(object sender, EventArgs e)
        {
            if (amtLength < 10 && canEnter)
            {
                transferAmt = transferAmt + 3;
                amtLength++;
                button0.Enabled = true;
                buttonDelete.Enabled = true;
                buttonEnter.Enabled = true;
            }

            transferAmountTB.Text = "$" + transferAmt + ".00";
        }

        //button "4"
        private void button4_Click(object sender, EventArgs e)
        {
            if (amtLength < 10 && canEnter)
            {
                transferAmt = transferAmt + 4;
                amtLength++;
                button0.Enabled = true;
                buttonDelete.Enabled = true;
                buttonEnter.Enabled = true;
            }

            transferAmountTB.Text = "$" + transferAmt + ".00";
        }

        //button "5"
        private void button5_Click(object sender, EventArgs e)
        {
            if (amtLength < 10 && canEnter)
            {
                transferAmt = transferAmt + 5;
                amtLength++;
                button0.Enabled = true;
                buttonDelete.Enabled = true;
                buttonEnter.Enabled = true;
            }

            transferAmountTB.Text = "$" + transferAmt + ".00";
        }

        //button "6"
        private void button6_Click(object sender, EventArgs e)
        {
            if (amtLength < 10 && canEnter)
            {
                transferAmt = transferAmt + 6;
                amtLength++;
                button0.Enabled = true;
                buttonDelete.Enabled = true;
                buttonEnter.Enabled = true;
            }

            transferAmountTB.Text = "$" + transferAmt + ".00";
        }

        //button "7"
        private void button7_Click(object sender, EventArgs e)
        {
            if (amtLength < 10 && canEnter)
            {
                transferAmt = transferAmt + 7;
                amtLength++;
                button0.Enabled = true;
                buttonDelete.Enabled = true;
                buttonEnter.Enabled = true;
            }

            transferAmountTB.Text = "$" + transferAmt + ".00";
        }

        //button "8"
        private void button8_Click(object sender, EventArgs e)
        {
            if (amtLength < 10 && canEnter)
            {
                transferAmt = transferAmt + 8;
                amtLength++;
                button0.Enabled = true;
                buttonDelete.Enabled = true;
                buttonEnter.Enabled = true;
            }

            transferAmountTB.Text = "$" + transferAmt + ".00";
        }

        //button "9"
        private void button9_Click(object sender, EventArgs e)
        {
            if (amtLength < 10 && canEnter)
            {
                transferAmt = transferAmt + 9;
                amtLength++;
                button0.Enabled = true;
                buttonDelete.Enabled = true;
                buttonEnter.Enabled = true;
            }

            transferAmountTB.Text = "$" + transferAmt + ".00";
        }

        //button "0"
        private void button0_Click(object sender, EventArgs e)
        {
            if (amtLength < 10 && canEnter)
            {
                transferAmt = transferAmt + 0;
                amtLength++;
                buttonDelete.Enabled = true;
                buttonEnter.Enabled = true;
            }

            transferAmountTB.Text = "$" + transferAmt + ".00";
        }

        //delete button
        private void buttonDelete_Click(object sender, EventArgs e)
        {
            //if textbox has digits in it
            if(amtLength > 0 && canEnter)
            {
                //decrease the digits
                transferAmt = transferAmt.Substring(0, transferAmt.Length - 1);
                transferAmountTB.Text = "$" + transferAmt + ".00";
                amtLength--;
            }
            //if textbox does not have digits in it
            if (amtLength == 0)
            {
                //disable buttons and default the textbox
                button0.Enabled = false;
                buttonDelete.Enabled = false;
                buttonEnter.Enabled = false;
                transferAmountTB.Text = "$0.00";
            }
        }

        //enter button
        private void buttonEnter_Click(object sender, EventArgs e)
        {
            //disable certain buttons
            button0.Enabled = false;
            buttonDelete.Enabled = false;
            buttonEnter.Enabled = false;

            //Get old balance values
            oldBalanceOne = int.Parse(balanceSwapOne);
            oldBalanceTwo = int.Parse(balanceSwapTwo);

            //If the user entered no funds for transfer..
            if (amtLength == 0)
            {
                //display error message and set everything to default
                transferAmtDB = 0;
                errorLabel.Text = "You have selected no funds for transfer.";
                transferAmt = "";
                amtLength = 0;
                transferAmountTB.Text = transferAmt;
            } 
            //If the user entered funds for transfer
            else
            {
                //set transfer amount
                transferAmtDB = int.Parse(transferAmt);

                //If transfer amount is valid
                if(transferAmtDB <= oldBalanceOne)
                {
                    //Set new balance variables
                    updatedBalanceOne = oldBalanceOne - transferAmtDB;
                    updatedBalanceTwo = oldBalanceTwo + transferAmtDB;
                    updatedBalanceOneDB = updatedBalanceOne.ToString();
                    updatedBalanceTwoDB = updatedBalanceTwo.ToString();
                    
                    //set textbox back to default
                    transferAmt = "";
                    amtLength = 0;
                    transferAmountTB.Text = "$0.00";
                    
                    //transfer success confirmation message
                    errorLabel.Text = "Amount Transferred: $" + transferAmtDB + ".00";

                    //open database
                    link.Open();

                    //update database
                    MySqlCommand updateDatabaseBalance = new MySqlCommand("UPDATE corbinkiefneratmbalances SET balance" + boxIndexOne + " = " + updatedBalanceOneDB, link);
                    updateDatabaseBalance.ExecuteNonQuery();
                    MySqlCommand updateDatabaseBalanceTwo = new MySqlCommand("UPDATE corbinkiefneratmbalances SET balance" + boxIndexTwo + "= " + updatedBalanceTwoDB, link);
                    updateDatabaseBalanceTwo.ExecuteNonQuery();
                    MySqlCommand selectBalanceOne = new MySqlCommand("SELECT balance" + boxIndexOne + " FROM corbinkiefneratmbalances", link);
                    balanceSwapOne = selectBalanceOne.ExecuteScalar().ToString();
                    MySqlCommand selectBalanceTwo = new MySqlCommand("SELECT balance" + boxIndexTwo + " FROM corbinkiefneratmbalances", link);
                    balanceSwapTwo = selectBalanceTwo.ExecuteScalar().ToString();

                    //close database
                    link.Close();
                }
                //If transfer amount is invalid
                else
                {
                    //set textbox back to default
                    transferAmt = "";
                    amtLength = 0;
                    transferAmountTB.Text = "$0.00";
                    
                    //display error message letting the user know what happened
                    errorLabel.Text = "The amount entered exceeds the accounts funds.";
                }
            }

            //control combobox one
            switch (boxIndexOne)
            {
                case 1:
                    bal1 = balanceSwapOne;
                    break;
                case 2:
                    bal2 = balanceSwapOne;
                    break;
                case 3:
                    bal3 = balanceSwapOne;
                    break;
                case 4:
                    bal4 = balanceSwapOne;
                    break;
            }

            //control combobox two
            switch (boxIndexTwo)
            {
                case 1:
                    bal1 = balanceSwapTwo;
                    break;
                case 2:
                    bal2 = balanceSwapTwo;
                    break;
                case 3:
                    bal3 = balanceSwapTwo;
                    break;
                case 4:
                    bal4 = balanceSwapTwo;
                    break;
            }

            //set combobox text to the correct balance
            withdrawalBalanceTB.Text = "$" + balanceSwapOne + ".00";
            depositBalanceTB.Text = "$" + balanceSwapTwo + ".00";
        }
    }
}
