﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace CorbinKiefnerATM
{
    public partial class Withdrawal : Form
    {
        //update current balance
        private string withdrawAmt = "";
        private int amtLength = 0;

        //database update variables
        int oldBalance;
        int withdrawalAmountDB;
        int updatedBalance;
        string updatedBalanceDB;

        //store balancaes for each account and get checking account numbers
        private string bal1 = "";
        private string bal2 = "";
        private string bal3 = "";
        private string bal4 = "";
        private string checking1 = "";
        private string checking2 = "";
        private string checking3 = "";
        private string checking4 = "";

        //get current balance and current limit progress
        private string currentBalance = "";
        private int currentLimit;
        private int boxIndex;
        
        //database link
        MySqlConnection link = new MySqlConnection("server=157.89.28.29;user=student;database=csc340_db;port=3306;password=Maroon@21?;");

        //initialization
        public Withdrawal()
        {
            InitializeComponent();
            
            //disable specific buttons
            button0.Enabled = false;
            buttonDelete.Enabled = false;
            buttonEnter.Enabled = false;
            
            //Open database
            link.Open();

            //Get current limit progress
            MySqlCommand getCurrentLimit = new MySqlCommand("SELECT currentLimit FROM corbinkiefneratmtransaction", link);
            currentLimit = int.Parse(getCurrentLimit.ExecuteScalar().ToString());

            //Gather balances
            MySqlCommand DB1 = new MySqlCommand("SELECT balance1 FROM corbinkiefneratmbalances", link);
            bal1 = DB1.ExecuteScalar().ToString();
            MySqlCommand DB2 = new MySqlCommand("SELECT balance2 FROM corbinkiefneratmbalances", link);
            bal2 = DB2.ExecuteScalar().ToString();
            MySqlCommand DB3 = new MySqlCommand("SELECT balance3 FROM corbinkiefneratmbalances", link);
            bal3 = DB3.ExecuteScalar().ToString();
            MySqlCommand DB4 = new MySqlCommand("SELECT balance4 FROM corbinkiefneratmbalances", link);
            bal4 = DB4.ExecuteScalar().ToString();

            //Gather account numbers
            MySqlCommand getchecking1 = new MySqlCommand("SELECT account1 FROM corbinkiefneratmbalances", link);
            checking1 = (getchecking1.ExecuteScalar().ToString());
            MySqlCommand getchecking2 = new MySqlCommand("SELECT account2 FROM corbinkiefneratmbalances", link);
            checking2 = (getchecking2.ExecuteScalar().ToString());
            MySqlCommand getchecking3 = new MySqlCommand("SELECT account3 FROM corbinkiefneratmbalances", link);
            checking3 = (getchecking3.ExecuteScalar().ToString());
            MySqlCommand getchecking4 = new MySqlCommand("SELECT account4 FROM corbinkiefneratmbalances", link);
            checking4 = (getchecking4.ExecuteScalar().ToString());

            //Close database
            link.Close();

            //set default textbox content
            accountBalanceTB.Text = "$" + currentBalance + ".00";
            withdrawalAmountTB.Text = "$0.00";
            
            //initialize combobox items and select default
            withdrawalAccountCB.Items.Add(checking1);
            withdrawalAccountCB.Items.Add(checking2);
            withdrawalAccountCB.Items.Add(checking3);
            withdrawalAccountCB.Items.Add(checking4);
            withdrawalAccountCB.SelectedIndex = 0;
        }

        //return to main menu
        private void mainMenuButton_Click(object sender, EventArgs e)
        {
            this.Hide();
            Home form = new Home();
            form.ShowDialog();
            this.Close();
        }

        //log out
        private void logOutButton_Click(object sender, EventArgs e)
        {
            this.Hide();
            LogIn form = new LogIn();
            form.ShowDialog();
            this.Close();
        }

        //account select combobox
        private void withdrawalAccountCB_SelectedIndexChanged(object sender, EventArgs e)
        {
            boxIndex = withdrawalAccountCB.SelectedIndex + 1;

            switch (boxIndex)
            {
                case 1:
                    currentBalance = bal1;
                    accountBalanceTB.Text = "$" + currentBalance + ".00";
                    break;
                case 2:
                    currentBalance = bal2;
                    accountBalanceTB.Text = "$" + currentBalance + ".00";
                    break;
                case 3:
                    currentBalance = bal3;
                    accountBalanceTB.Text = "$" + currentBalance + ".00";
                    break;
                case 4:
                    currentBalance = bal4;
                    accountBalanceTB.Text = "$" + currentBalance + ".00";
                    break;
            }
        }

        //button "1"
        private void button1_Click(object sender, EventArgs e)
        {
            if (amtLength < 10)
            {
                withdrawAmt = withdrawAmt + 1;
                amtLength++;
                button0.Enabled = true;
                buttonDelete.Enabled = true;
                buttonEnter.Enabled = true;
            }

            withdrawalAmountTB.Text = "$" + withdrawAmt + ".00";
        }

        //button "2"
        private void button2_Click(object sender, EventArgs e)
        {
            if (amtLength < 10)
            {
                withdrawAmt = withdrawAmt + 2;
                amtLength++;
                button0.Enabled = true;
                buttonDelete.Enabled = true;
                buttonEnter.Enabled = true;
            }

            withdrawalAmountTB.Text = "$" + withdrawAmt + ".00";
        }

        //button "3"
        private void button3_Click(object sender, EventArgs e)
        {
            if (amtLength < 10)
            {
                withdrawAmt = withdrawAmt + 3;
                amtLength++;
                button0.Enabled = true;
                buttonDelete.Enabled = true;
                buttonEnter.Enabled = true;
            }

            withdrawalAmountTB.Text = "$" + withdrawAmt + ".00";
        }

        //button "4"
        private void button4_Click(object sender, EventArgs e)
        {
            if (amtLength < 10)
            {
                withdrawAmt = withdrawAmt + 4;
                amtLength++;
                button0.Enabled = true;
                buttonDelete.Enabled = true;
                buttonEnter.Enabled = true;
            }

            withdrawalAmountTB.Text = "$" + withdrawAmt + ".00";
        }

        //button "5"
        private void button5_Click(object sender, EventArgs e)
        {
            if (amtLength < 10)
            {
                withdrawAmt = withdrawAmt + 5;
                amtLength++;
                button0.Enabled = true;
                buttonDelete.Enabled = true;
                buttonEnter.Enabled = true;
            }

            withdrawalAmountTB.Text = "$" + withdrawAmt + ".00";
        }

        //button "6"
        private void button6_Click(object sender, EventArgs e)
        {
            if (amtLength < 10)
            {
                withdrawAmt = withdrawAmt + 6;
                amtLength++;
                button0.Enabled = true;
                buttonDelete.Enabled = true;
                buttonEnter.Enabled = true;
            }

            withdrawalAmountTB.Text = "$" + withdrawAmt + ".00";
        }

        //button "7"
        private void button7_Click(object sender, EventArgs e)
        {
            if (amtLength < 10)
            {
                withdrawAmt = withdrawAmt + 7;
                amtLength++;
                button0.Enabled = true;
                buttonDelete.Enabled = true;
                buttonEnter.Enabled = true;
            }

            withdrawalAmountTB.Text = "$" + withdrawAmt + ".00";
        }

        //button "8"
        private void button8_Click(object sender, EventArgs e)
        {
            if (amtLength < 10)
            {
                withdrawAmt = withdrawAmt + 8;
                amtLength++;
                button0.Enabled = true;
                buttonDelete.Enabled = true;
                buttonEnter.Enabled = true;
            }

            withdrawalAmountTB.Text = "$" + withdrawAmt + ".00";
        }

        //button "9"
        private void button9_Click(object sender, EventArgs e)
        {
            if (amtLength < 10)
            {
                withdrawAmt = withdrawAmt + 9;
                amtLength++;
                button0.Enabled = true;
                buttonDelete.Enabled = true;
                buttonEnter.Enabled = true;
            }

            withdrawalAmountTB.Text = "$" + withdrawAmt + ".00";
        }

        //button "0"
        private void button0_Click(object sender, EventArgs e)
        {
            if (amtLength < 10)
            {
                withdrawAmt = withdrawAmt + 0;
                amtLength++;
                buttonDelete.Enabled = true;
                buttonEnter.Enabled = true;
            }

            withdrawalAmountTB.Text = "$" + withdrawAmt + ".00";
        }

        //delete button
        private void buttonDelete_Click(object sender, EventArgs e)
        {
            //if the textbox is not empty
            if (amtLength > 0)
            {
                //lower the input number
                withdrawAmt = withdrawAmt.Substring(0, withdrawAmt.Length - 1);
                withdrawalAmountTB.Text = "$" + withdrawAmt + ".00";
                amtLength--;
            }
            //if the textbox is empty
            if (amtLength == 0)
            {
                //disable certain buttons
                button0.Enabled = false;
                buttonDelete.Enabled = false;
                buttonEnter.Enabled = false;
                withdrawalAmountTB.Text = "$0.00";
            }
        }

        //enter button
        private void buttonEnter_Click(object sender, EventArgs e)
        {
            //set buttons to disabled
            buttonEnter.Enabled = false;
            buttonDelete.Enabled = false;
            button0.Enabled = false;

            //Old balance and deposit amount
            oldBalance = int.Parse(currentBalance);
            withdrawalAmountDB = int.Parse(withdrawAmt);

            //New balance
            updatedBalance = oldBalance - withdrawalAmountDB;
            updatedBalanceDB = updatedBalance.ToString();

            //If the withdrawal is a valid transaction...
            if (currentLimit <= 3000 - withdrawalAmountDB)
            {
                //If withdrawal amount is less than the funds in the account...
                if (withdrawalAmountDB <= oldBalance)
                {
                    //change current limit after valid transaction
                    currentLimit += withdrawalAmountDB;
                    
                    //withdrawal confirmation message
                    errorLabel.Text = "$" + withdrawAmt + ".00 withdrawn.";

                    //Update the database
                    link.Open();
                    MySqlCommand updateBalanceDB = new MySqlCommand("UPDATE corbinkiefneratmbalances SET balance" + boxIndex + " = " + updatedBalanceDB, link);
                    updateBalanceDB.ExecuteNonQuery();
                    MySqlCommand updateCurrentLimit = new MySqlCommand("UPDATE corbinkiefneratmtransaction SET currentLimit = " + currentLimit, link);
                    updateCurrentLimit.ExecuteNonQuery();
                    MySqlCommand lastTransaction = new MySqlCommand("UPDATE corbinkiefneratmtransaction SET lastTransactionAmount = " + withdrawalAmountDB, link);
                    lastTransaction.ExecuteNonQuery();
                    MySqlCommand selectBalanceDB = new MySqlCommand("SELECT balance" + boxIndex + " FROM corbinkiefneratmbalances", link);
                    currentBalance = selectBalanceDB.ExecuteScalar().ToString();
                    link.Close();

                    //disable certain buttons again
                    button0.Enabled = false;
                    buttonDelete.Enabled = false;
                    buttonEnter.Enabled = false;

                    //set textboxes back to normal
                    withdrawAmt = "";
                    amtLength = 0;
                    withdrawalAmountTB.Text = "$0.00";
                    accountBalanceTB.Text = "$" + currentBalance + ".00";
                }
                //if withdrawal amount is invalid due to lack of funds...
                else
                {
                    //let the user know why the deposit failed
                    errorLabel.Text = "insufficient funds.";

                    //Set texts box back to normal
                    withdrawAmt = "";
                    amtLength = 0;
                    withdrawalAmountTB.Text = "$0.00";
                }
            }
            //If the transaction is invalid due to transaction limit...
            else
            {
                //let the user know why the deposit failed
                errorLabel.Text = "This exceeds your daily limit.";

                //Set texts box back to normal
                withdrawAmt = "";
                amtLength = 0;
                withdrawalAmountTB.Text = "$0.00";
            }

            //set buttons to disabled again
            buttonEnter.Enabled = false;
            buttonDelete.Enabled = false;
            button0.Enabled = false;

            //call the correct balance according to the indicated combobox index
            switch (boxIndex)
            {
                case 1:
                    bal1 = currentBalance;
                    break;
                case 2:
                    bal2 = currentBalance;
                    break;
                case 3:
                    bal3 = currentBalance;
                    break;
                case 4:
                    bal4 = currentBalance;
                    break;
            }
        }
    }
}
