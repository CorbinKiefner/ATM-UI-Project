﻿using System;
using System.Drawing;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace CorbinKiefnerATM
{
    public partial class LogIn : Form
    {
        //database link
        MySqlConnection link = new MySqlConnection("server=157.89.28.29;user=student;database=csc340_db;port=3306;password=Maroon@21?;");
        
        //Variables to track the progress of card entry
        private string cardNumber = "";
        private int cardLength = 0;
        private bool enteringCard = true;
        string card;
        string correctCard = "";

        //Variables to track the progress of pin entry
        private string pinNumber = "";
        private int pinLength = 0;
        private bool enteringPin = false;
        string pin;
        string correctPin = "";

        //initialization
        public LogIn()
        {
            InitializeComponent();

            //enter button disabled by default
            buttonEnter.Enabled = false;
        }
        
        //click "ZZZ Bank" to bypass the log in
        //TESTING PURPOSES ONLY
        private void HomeTitle_Click_1(object sender, EventArgs e)
        {
            this.Hide();
            Home form = new Home();
            form.ShowDialog();
            this.Close();
        }

        //Close program button
        //TESTING PURPOSES ONLY
        private void button10_Click(object sender, EventArgs e)
        {
            //close application
            Application.Exit();
        }

        //DATABASE RESET BUTTON
        private void button11_Click(object sender, EventArgs e)
        {
            //reset balances for testing purposes
            link.Open();
            MySqlCommand resetCurrentLimit = new MySqlCommand("UPDATE corbinkiefneratmtransaction SET currentLimit = " + 0, link);
            resetCurrentLimit.ExecuteNonQuery();
            MySqlCommand resetBalance1 = new MySqlCommand("UPDATE corbinkiefneratmbalances SET balance1 = " + 1000, link);
            resetBalance1.ExecuteNonQuery();
            MySqlCommand resetBalance2 = new MySqlCommand("UPDATE corbinkiefneratmbalances SET balance2 = " + 2500, link);
            resetBalance2.ExecuteNonQuery();
            MySqlCommand resetBalance3 = new MySqlCommand("UPDATE corbinkiefneratmbalances SET balance3 = " + 5000, link);
            resetBalance3.ExecuteNonQuery();
            MySqlCommand resetBalance4 = new MySqlCommand("UPDATE corbinkiefneratmbalances SET balance4 = " + 10000, link);
            resetBalance4.ExecuteNonQuery();
            link.Close();
        }

        //enter button
        private void buttonEnter_Click(object sender, EventArgs e)
        {
            //open database and retrieve card and pin number
            link.Open();
            pin = "SELECT pinNum FROM corbinkiefneratmaccounts WHERE pinNum= " + pinNumber;
            MySqlCommand confirmPin = new MySqlCommand(pin, link);
            card = "SELECT cardNum FROM corbinkiefneratmaccounts WHERE cardNum= " + cardNumber;
            MySqlCommand confirmCard = new MySqlCommand(card, link);

            //if the pin number is empty...
            if (confirmPin.ExecuteScalar() == null)
            {
                correctPin = "" + Int16.MinValue;
            }
            //if pin number is not empty...
            else
            {
                correctPin = confirmPin.ExecuteScalar().ToString();
            }

            //If the card number is empty...
            if (confirmCard.ExecuteScalar() == null)
            {
                correctCard = "" + Int16.MinValue;
            }
            //if card number is not empty...
            else
            {
                correctCard = confirmCard.ExecuteScalar().ToString();
            }

            //close database
            link.Close();

            //if the log in credentials are correct, go to the home page
            if (correctPin == pinNumber && correctCard == cardNumber)
            {
                //Set values to default
                cardNumber = "";
                pinNumber = "";
                cardLength = 0;
                pinLength = 0;
                cardNumberTB.Text = cardNumber;
                pinNumberTB.Text = pinNumber;

                //load main menu
                this.Hide();
                Home newForm = new Home();
                newForm.ShowDialog();
                this.Close();
            }
            //If they are not...
            else
            {
                //Set values to default
                cardNumber = "";
                pinNumber = "";
                cardLength = 0;
                pinLength = 0;
                cardNumberTB.Text = cardNumber;
                pinNumberTB.Text = pinNumber;

                //reset credential tracking variables
                enteringCard = true;
                enteringPin = false;

                //display an error label and disable the enter button
                errorLabel.Text = "Invalid credentials.";
                errorLabel.ForeColor = Color.Red;
                buttonEnter.Enabled = false;
            }
        }

        //button "1"
        //THIS CODE IS THE SAME FOR EVERY BUTTON
        private void button1_Click(object sender, EventArgs e)
        {
            //if the user is still entering the card, add digits to the card text box
            if (enteringCard)
            {
                if (cardLength < 16)
                {
                    cardNumber += 1;
                    cardLength++;
                }
                if (cardLength == 16)
                {
                    enteringCard = false;
                    enteringPin = true;
                }
                cardNumberTB.Text = cardNumber;
            }
            //if the user is entering the pin, add digits to the pin text box
            else
            {
                if(pinLength < 4)
                {
                    pinNumber += 1;
                    pinLength++;
                }
                if(pinLength == 4)
                {
                    buttonEnter.Enabled = true;
                }
                pinNumberTB.Text = pinNumber;
            }
        }

        //button "2"
        private void button2_Click(object sender, EventArgs e)
        {
            if (enteringCard)
            {
                if (cardLength < 16)
                {
                    cardNumber += 2;
                    cardLength++;
                }
                cardNumberTB.Text = cardNumber;
                if (cardLength == 16)
                {
                    enteringCard = false;
                    enteringPin = true;
                }
            }
            else
            {
                if (pinLength < 4)
                {
                    pinNumber += 2;
                    pinLength++;
                }
                if (pinLength == 4)
                {
                    buttonEnter.Enabled = true;
                }
                pinNumberTB.Text = pinNumber;
            }
        }

        //button "3"
        private void button3_Click(object sender, EventArgs e)
        {
            if (enteringCard)
            {
                if (cardLength < 16)
                {
                    cardNumber += 3;
                    cardLength++;
                }
                cardNumberTB.Text = cardNumber;
                if (cardLength == 16)
                {
                    enteringCard = false;
                    enteringPin = true;
                }
            }
            else
            {
                if (pinLength < 4)
                {
                    pinNumber += 3;
                    pinLength++;
                }
                if (pinLength == 4)
                {
                    buttonEnter.Enabled = true;
                }
                pinNumberTB.Text = pinNumber;
            }
        }

        //button "4"
        private void button4_Click(object sender, EventArgs e)
        {
            if (enteringCard)
            {
                if (cardLength < 16)
                {
                    cardNumber += 4;
                    cardLength++;
                }
                cardNumberTB.Text = cardNumber;
                if (cardLength == 16)
                {
                    enteringCard = false;
                    enteringPin = true;
                }
            }
            else
            {
                if (pinLength < 4)
                {
                    pinNumber += 4;
                    pinLength++;
                }
                if (pinLength == 4)
                {
                    buttonEnter.Enabled = true;
                }
                pinNumberTB.Text = pinNumber;
            }
        }

        //button "5"
        private void button5_Click(object sender, EventArgs e)
        {
            if (enteringCard)
            {
                if (cardLength < 16)
                {
                    cardNumber += 5;
                    cardLength++;
                }
                cardNumberTB.Text = cardNumber;
                if (cardLength == 16)
                {
                    enteringCard = false;
                    enteringPin = true;
                }
            }
            else
            {
                if (pinLength < 4)
                {
                    pinNumber += 5;
                    pinLength++;
                }
                if (pinLength == 4)
                {
                    buttonEnter.Enabled = true;
                }
                pinNumberTB.Text = pinNumber;
            }
        }

        //button "6"
        private void button6_Click(object sender, EventArgs e)
        {
            if (enteringCard)
            {
                if (cardLength < 16)
                {
                    cardNumber += 6;
                    cardLength++;
                }
                cardNumberTB.Text = cardNumber;
                if (cardLength == 16)
                {
                    enteringCard = false;
                    enteringPin = true;
                }
            }
            else
            {
                if (pinLength < 4)
                {
                    pinNumber += 6;
                    pinLength++;
                }
                if (pinLength == 4)
                {
                    buttonEnter.Enabled = true;
                }
                pinNumberTB.Text = pinNumber;
            }
        }

        //button "7"
        private void button7_Click(object sender, EventArgs e)
        {
            if (enteringCard)
            {
                if (cardLength < 16)
                {
                    cardNumber += 7;
                    cardLength++;
                }
                cardNumberTB.Text = cardNumber;
                if (cardLength == 16)
                {
                    enteringCard = false;
                    enteringPin = true;
                }
            }
            else
            {
                if (pinLength < 4)
                {
                    pinNumber += 7;
                    pinLength++;
                }
                if (pinLength == 4)
                {
                    buttonEnter.Enabled = true;
                }
                pinNumberTB.Text = pinNumber;
            }
        }

        //button "8"
        private void button8_Click(object sender, EventArgs e)
        {
            if (enteringCard)
            {
                if (cardLength < 16)
                {
                    cardNumber += 8;
                    cardLength++;
                }
                cardNumberTB.Text = cardNumber;
                if (cardLength == 16)
                {
                    enteringCard = false;
                    enteringPin = true;
                }
            }
            else
            {
                if (pinLength < 4)
                {
                    pinNumber += 8;
                    pinLength++;
                }
                if (pinLength == 4)
                {
                    buttonEnter.Enabled = true;
                }
                pinNumberTB.Text = pinNumber;
            }
        }

        //button "9"
        private void button9_Click(object sender, EventArgs e)
        {
            if (enteringCard)
            {
                if (cardLength < 16)
                {
                    cardNumber += 9;
                    cardLength++;
                }
                cardNumberTB.Text = cardNumber;
                if (cardLength == 16)
                {
                    enteringCard = false;
                    enteringPin = true;
                }
            }
            else
            {
                if (pinLength < 4)
                {
                    pinNumber += 9;
                    pinLength++;
                }
                if (pinLength == 4)
                {
                    buttonEnter.Enabled = true;
                }
                pinNumberTB.Text = pinNumber;
            }
        }

        //button "0"
        private void button0_Click(object sender, EventArgs e)
        {
            if (enteringCard)
            {
                if (cardLength < 16)
                {
                    cardNumber += 0;
                    cardLength++;
                }
                cardNumberTB.Text = cardNumber;
                if (cardLength == 16)
                {
                    enteringCard = false;
                    enteringPin = true;
                }
            }
            else
            {
                if (pinLength < 4)
                {
                    pinNumber += 0;
                    pinLength++;
                }
                if (pinLength == 4)
                {
                    buttonEnter.Enabled = true;
                }
                pinNumberTB.Text = pinNumber;
            }
        }

        //delete character button
        private void buttonDelete_Click(object sender, EventArgs e)
        {
            //always disable enter, as the information is not complete
            buttonEnter.Enabled = false;

            //if entering card, delete digits from card until empty
            if (enteringCard)
            {
                if(cardLength > 0)
                {
                    cardNumber = cardNumber.Substring(0, cardNumber.Length - 1);
                    cardNumberTB.Text = cardNumber;
                    cardLength--;
                }
            } 
            //if entering pin, delete digits from pin until empty, then switch to card
            if (enteringPin)
            {
                if (pinLength >= 1)
                {
                    pinNumber = pinNumber.Substring(0, pinNumber.Length - 1);
                    pinNumberTB.Text = pinNumber;
                    pinLength--;
                } 
                if(pinLength == 0)
                {
                    pinNumber = "";
                    pinNumberTB.Text = pinNumber;
                    pinLength = 0;
                    enteringPin = false;
                    enteringCard = true;
                }
            }
        }
    }
}
