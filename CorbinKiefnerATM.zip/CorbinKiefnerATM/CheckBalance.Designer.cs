﻿
namespace CorbinKiefnerATM
{
    partial class CheckBalance
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label3 = new System.Windows.Forms.Label();
            this.accountBalanceTB = new System.Windows.Forms.TextBox();
            this.viewAccountCB = new System.Windows.Forms.ComboBox();
            this.label1 = new System.Windows.Forms.Label();
            this.HomeTitle = new System.Windows.Forms.Label();
            this.mainMenuButton = new System.Windows.Forms.Button();
            this.logOutButton = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Century Gothic", 8F);
            this.label3.ForeColor = System.Drawing.Color.SteelBlue;
            this.label3.Location = new System.Drawing.Point(89, 104);
            this.label3.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(105, 16);
            this.label3.TabIndex = 53;
            this.label3.Text = "Account Balance:";
            // 
            // accountBalanceTB
            // 
            this.accountBalanceTB.Enabled = false;
            this.accountBalanceTB.Location = new System.Drawing.Point(195, 101);
            this.accountBalanceTB.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.accountBalanceTB.Name = "accountBalanceTB";
            this.accountBalanceTB.ReadOnly = true;
            this.accountBalanceTB.Size = new System.Drawing.Size(127, 20);
            this.accountBalanceTB.TabIndex = 52;
            // 
            // viewAccountCB
            // 
            this.viewAccountCB.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.viewAccountCB.FormattingEnabled = true;
            this.viewAccountCB.Location = new System.Drawing.Point(195, 77);
            this.viewAccountCB.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.viewAccountCB.Name = "viewAccountCB";
            this.viewAccountCB.Size = new System.Drawing.Size(127, 21);
            this.viewAccountCB.TabIndex = 51;
            this.viewAccountCB.SelectedIndexChanged += new System.EventHandler(this.withdrawalAccountCB_SelectedIndexChanged);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Century Gothic", 8F);
            this.label1.ForeColor = System.Drawing.Color.SteelBlue;
            this.label1.Location = new System.Drawing.Point(86, 82);
            this.label1.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(108, 16);
            this.label1.TabIndex = 50;
            this.label1.Text = "Selected Account:";
            // 
            // HomeTitle
            // 
            this.HomeTitle.AutoSize = true;
            this.HomeTitle.Font = new System.Drawing.Font("Century Gothic", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.HomeTitle.ForeColor = System.Drawing.Color.SteelBlue;
            this.HomeTitle.Location = new System.Drawing.Point(207, 35);
            this.HomeTitle.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.HomeTitle.Name = "HomeTitle";
            this.HomeTitle.Size = new System.Drawing.Size(105, 26);
            this.HomeTitle.TabIndex = 54;
            this.HomeTitle.Text = "ZZZ Bank";
            // 
            // mainMenuButton
            // 
            this.mainMenuButton.BackColor = System.Drawing.Color.White;
            this.mainMenuButton.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.mainMenuButton.Font = new System.Drawing.Font("Century Gothic", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.mainMenuButton.ForeColor = System.Drawing.Color.SteelBlue;
            this.mainMenuButton.Location = new System.Drawing.Point(364, 260);
            this.mainMenuButton.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.mainMenuButton.Name = "mainMenuButton";
            this.mainMenuButton.Size = new System.Drawing.Size(90, 25);
            this.mainMenuButton.TabIndex = 56;
            this.mainMenuButton.Text = "Main Menu";
            this.mainMenuButton.UseVisualStyleBackColor = false;
            this.mainMenuButton.Click += new System.EventHandler(this.mainMenuButton_Click);
            // 
            // logOutButton
            // 
            this.logOutButton.BackColor = System.Drawing.Color.Red;
            this.logOutButton.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.logOutButton.Font = new System.Drawing.Font("Century Gothic", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.logOutButton.ForeColor = System.Drawing.Color.White;
            this.logOutButton.Location = new System.Drawing.Point(458, 260);
            this.logOutButton.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.logOutButton.Name = "logOutButton";
            this.logOutButton.Size = new System.Drawing.Size(67, 25);
            this.logOutButton.TabIndex = 55;
            this.logOutButton.Text = "Log Out";
            this.logOutButton.UseVisualStyleBackColor = false;
            this.logOutButton.Click += new System.EventHandler(this.logOutButton_Click);
            // 
            // CheckBalance
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(533, 292);
            this.Controls.Add(this.mainMenuButton);
            this.Controls.Add(this.logOutButton);
            this.Controls.Add(this.HomeTitle);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.accountBalanceTB);
            this.Controls.Add(this.viewAccountCB);
            this.Controls.Add(this.label1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.Name = "CheckBalance";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "CheckBalance";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox accountBalanceTB;
        private System.Windows.Forms.ComboBox viewAccountCB;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label HomeTitle;
        private System.Windows.Forms.Button mainMenuButton;
        private System.Windows.Forms.Button logOutButton;
    }
}