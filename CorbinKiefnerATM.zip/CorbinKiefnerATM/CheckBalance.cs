﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace CorbinKiefnerATM
{
    public partial class CheckBalance : Form
    {
        //Database link
        MySqlConnection link = new MySqlConnection("server=157.89.28.29;user=student;database=csc340_db;port=3306;password=Maroon@21?;");
        
        //Index and limit variables
        int boxIndex;
        int currentLimit;

        //balance variables
        private string currentBalance = "";
        private string bal1 = "";
        private string bal2 = "";
        private string bal3 = "";
        private string bal4 = "";
        private string checking1 = "";
        private string checking2 = "";
        private string checking3 = "";
        private string checking4 = "";

        //initialization
        public CheckBalance()
        {
            InitializeComponent();

            //Open database
            link.Open();

            //Get current limit
            MySqlCommand getCurrentLimit = new MySqlCommand("SELECT currentLimit FROM corbinkiefneratmtransaction", link);
            currentLimit = int.Parse(getCurrentLimit.ExecuteScalar().ToString());

            //Gather balances
            MySqlCommand DB1 = new MySqlCommand("SELECT balance1 FROM corbinkiefneratmbalances", link);
            bal1 = DB1.ExecuteScalar().ToString();
            MySqlCommand DB2 = new MySqlCommand("SELECT balance2 FROM corbinkiefneratmbalances", link);
            bal2 = DB2.ExecuteScalar().ToString();
            MySqlCommand DB3 = new MySqlCommand("SELECT balance3 FROM corbinkiefneratmbalances", link);
            bal3 = DB3.ExecuteScalar().ToString();
            MySqlCommand DB4 = new MySqlCommand("SELECT balance4 FROM corbinkiefneratmbalances", link);
            bal4 = DB4.ExecuteScalar().ToString();

            //Gather account numbers
            MySqlCommand getchecking1 = new MySqlCommand("SELECT account1 FROM corbinkiefneratmbalances", link);
            checking1 = (getchecking1.ExecuteScalar().ToString());
            MySqlCommand getchecking2 = new MySqlCommand("SELECT account2 FROM corbinkiefneratmbalances", link);
            checking2 = (getchecking2.ExecuteScalar().ToString());
            MySqlCommand getchecking3 = new MySqlCommand("SELECT account3 FROM corbinkiefneratmbalances", link);
            checking3 = (getchecking3.ExecuteScalar().ToString());
            MySqlCommand getchecking4 = new MySqlCommand("SELECT account4 FROM corbinkiefneratmbalances", link);
            checking4 = (getchecking4.ExecuteScalar().ToString());

            //close database
            link.Close();

            //initialize combobox items and set default index
            viewAccountCB.Items.Add(checking1);
            viewAccountCB.Items.Add(checking2);
            viewAccountCB.Items.Add(checking3);
            viewAccountCB.Items.Add(checking4);
            viewAccountCB.Items.Add("Daily Limit Remaining");
            viewAccountCB.SelectedIndex = 0;
        }

        //log out button
        private void logOutButton_Click(object sender, EventArgs e)
        {
            this.Hide();
            LogIn form = new LogIn();
            form.ShowDialog();
            this.Close();
        }

        //main menu button
        private void mainMenuButton_Click(object sender, EventArgs e)
        {
            this.Hide();
            Home form = new Home();
            form.ShowDialog();
            this.Close();
        }

        //account select combobox
        private void withdrawalAccountCB_SelectedIndexChanged(object sender, EventArgs e)
        {
            //Set the current selection within combobox
            boxIndex = viewAccountCB.SelectedIndex + 1;

            //switch statement controls the contents of the textbox based off the users choice in the combobox
            switch (boxIndex)
            {
                case 1:
                    currentBalance = bal1;
                    accountBalanceTB.Text = "$" + currentBalance + ".00";
                    break;
                case 2:
                    currentBalance = bal2;
                    accountBalanceTB.Text = "$" + currentBalance + ".00";
                    break;
                case 3:
                    currentBalance = bal3;
                    accountBalanceTB.Text = "$" + currentBalance + ".00";
                    break;
                case 4:
                    currentBalance = bal4;
                    accountBalanceTB.Text = "$" + currentBalance + ".00";
                    break;
                case 5:
                    accountBalanceTB.Text = "$" + ((3000 - currentLimit).ToString()) + ".00";
                    break;
            }
        }
    }
}
