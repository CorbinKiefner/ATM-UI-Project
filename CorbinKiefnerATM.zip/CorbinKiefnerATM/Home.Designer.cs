﻿
namespace CorbinKiefnerATM
{
    partial class Home
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.HomeTitle = new System.Windows.Forms.Label();
            this.depositButton = new System.Windows.Forms.Button();
            this.withdrawalButton = new System.Windows.Forms.Button();
            this.transferFundsButton = new System.Windows.Forms.Button();
            this.checkBalanceButton = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // HomeTitle
            // 
            this.HomeTitle.AutoSize = true;
            this.HomeTitle.Font = new System.Drawing.Font("Century Gothic", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.HomeTitle.ForeColor = System.Drawing.Color.SteelBlue;
            this.HomeTitle.Location = new System.Drawing.Point(311, 54);
            this.HomeTitle.Name = "HomeTitle";
            this.HomeTitle.Size = new System.Drawing.Size(105, 26);
            this.HomeTitle.TabIndex = 0;
            this.HomeTitle.Text = "ZZZ Bank";
            // 
            // depositButton
            // 
            this.depositButton.BackColor = System.Drawing.Color.SteelBlue;
            this.depositButton.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.depositButton.Font = new System.Drawing.Font("Century Gothic", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.depositButton.ForeColor = System.Drawing.Color.White;
            this.depositButton.Location = new System.Drawing.Point(302, 102);
            this.depositButton.Name = "depositButton";
            this.depositButton.Size = new System.Drawing.Size(170, 46);
            this.depositButton.TabIndex = 1;
            this.depositButton.Text = "Deposit";
            this.depositButton.UseVisualStyleBackColor = false;
            this.depositButton.Click += new System.EventHandler(this.depositButton_Click);
            // 
            // withdrawalButton
            // 
            this.withdrawalButton.BackColor = System.Drawing.Color.SteelBlue;
            this.withdrawalButton.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.withdrawalButton.Font = new System.Drawing.Font("Century Gothic", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.withdrawalButton.ForeColor = System.Drawing.Color.White;
            this.withdrawalButton.Location = new System.Drawing.Point(302, 154);
            this.withdrawalButton.Name = "withdrawalButton";
            this.withdrawalButton.Size = new System.Drawing.Size(170, 46);
            this.withdrawalButton.TabIndex = 2;
            this.withdrawalButton.Text = "Withdrawal";
            this.withdrawalButton.UseVisualStyleBackColor = false;
            this.withdrawalButton.Click += new System.EventHandler(this.withdrawalButton_Click);
            // 
            // transferFundsButton
            // 
            this.transferFundsButton.BackColor = System.Drawing.Color.SteelBlue;
            this.transferFundsButton.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.transferFundsButton.Font = new System.Drawing.Font("Century Gothic", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.transferFundsButton.ForeColor = System.Drawing.Color.White;
            this.transferFundsButton.Location = new System.Drawing.Point(302, 206);
            this.transferFundsButton.Name = "transferFundsButton";
            this.transferFundsButton.Size = new System.Drawing.Size(170, 46);
            this.transferFundsButton.TabIndex = 3;
            this.transferFundsButton.Text = "Transfer Funds";
            this.transferFundsButton.UseVisualStyleBackColor = false;
            this.transferFundsButton.Click += new System.EventHandler(this.transferFundsButton_Click);
            // 
            // checkBalanceButton
            // 
            this.checkBalanceButton.BackColor = System.Drawing.Color.SteelBlue;
            this.checkBalanceButton.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.checkBalanceButton.Font = new System.Drawing.Font("Century Gothic", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.checkBalanceButton.ForeColor = System.Drawing.Color.White;
            this.checkBalanceButton.Location = new System.Drawing.Point(302, 258);
            this.checkBalanceButton.Name = "checkBalanceButton";
            this.checkBalanceButton.Size = new System.Drawing.Size(170, 46);
            this.checkBalanceButton.TabIndex = 4;
            this.checkBalanceButton.Text = "Check Balance";
            this.checkBalanceButton.UseVisualStyleBackColor = false;
            this.checkBalanceButton.Click += new System.EventHandler(this.checkBalanceButton_Click);
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.Color.Red;
            this.button1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button1.Font = new System.Drawing.Font("Century Gothic", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button1.ForeColor = System.Drawing.Color.White;
            this.button1.Location = new System.Drawing.Point(302, 310);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(170, 46);
            this.button1.TabIndex = 5;
            this.button1.Text = "Log Out";
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // Home
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.checkBalanceButton);
            this.Controls.Add(this.transferFundsButton);
            this.Controls.Add(this.withdrawalButton);
            this.Controls.Add(this.depositButton);
            this.Controls.Add(this.HomeTitle);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "Home";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "ZZZ Bank Main Menu";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label HomeTitle;
        private System.Windows.Forms.Button depositButton;
        private System.Windows.Forms.Button withdrawalButton;
        private System.Windows.Forms.Button transferFundsButton;
        private System.Windows.Forms.Button checkBalanceButton;
        private System.Windows.Forms.Button button1;
    }
}

