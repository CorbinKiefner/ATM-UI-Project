﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CorbinKiefnerATM
{
    public partial class Home : Form
    {
        //initialization
        public Home()
        {
            InitializeComponent();
        }

        //deposit
        private void depositButton_Click(object sender, EventArgs e)
        {
            this.Hide();
            Deposit form = new Deposit();
            form.ShowDialog();
            this.Close();
        }

        //withdrawal
        private void withdrawalButton_Click(object sender, EventArgs e)
        {
            this.Hide();
            Withdrawal form = new Withdrawal();
            form.ShowDialog();
            this.Close();
        }

        //transfer
        private void transferFundsButton_Click(object sender, EventArgs e)
        {
            this.Hide();
            Transfer form = new Transfer();
            form.ShowDialog();
            this.Close();
        }

        //check balance
        private void checkBalanceButton_Click(object sender, EventArgs e)
        {
            this.Hide();
            CheckBalance form = new CheckBalance();
            form.ShowDialog();
            this.Close();
        }

        //log out
        private void button1_Click(object sender, EventArgs e)
        {
            this.Hide();
            LogIn form = new LogIn();
            form.ShowDialog();
            this.Close();
        }
    }
}
